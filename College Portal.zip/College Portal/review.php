<?php
	
$college=$_POST['college'];
$email=$_POST['email'];
$rating=$_POST['rating'];
$comment=$_POST['comment'];

if (!empty($college) || !empty($email) || !empty($rating) || !empty($comment)){
	
$host= "localhost";
$dbUsername= "root";
$dbPassword= "";
$dbname= "college reviews";

$conn= new mysqli($host, $dbUsername, $dbPassword, $dbname);

if (mysqli_connect_error()){
die('Connect Error('.mysqli_connect_error().')'.mysqli_conncet_error());
	
}	
else{
$SELECT = "SELECT email From Reviews Where email = ? Limit 1";
$INSERT = "INSERT Into Reviews (college, email, rating, comment) values(?,?,?,?)";

$stmt = $conn->prepare($SELECT);
$stmt-> bind_param("s", $email);
$stmt-> execute();
$stmt-> bind_result($email);
$stmt-> store_result();
$rnum = $stmt->num_rows;

if ($rnum==0){  
$stmt->close();
	
$stmt = $conn->prepare($INSERT);
$stmt-> bind_param("ssss", $college, $email, $rating, $comment);
$stmt-> execute();
echo "<h4>Review saved successfully</h4>";
}
else{ 
echo "<h4>This email has already been used. </h4>"; 
}
$stmt->close();
$conn->close();	
}
}
else {
echo "<h4>Please fill in everything and try again.</h4>";
die();	
}

?>