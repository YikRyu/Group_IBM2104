<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!--
Template Name: Internet Business
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <title>College Portal - Search</title>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <link rel="stylesheet" href="layout/styles/layout.css" type="text/css" />
    <script type="text/javascript" src="layout/scripts/jquery.min.js"></script>
    <script type="text/javascript" src="layout/scripts/jquery.easing.1.3.js"></script>
    <script type="text/javascript" src="layout/scripts/jquery.hslides.1.0.js"></script>
    <script type="text/javascript">
$((function () {
    $('#accordion').hSlides({
        totalWidth: 920,
        totalHeight: 300,
        minPanelWidth: 111,
        maxPanelWidth: 476,
		easing: "easeOutBack",
		activeClass: 'current'
    });
}));
    </script>
</head>

<body id="top">
    <div id="header">
        <div class="wrapper">
            <div class="fl_left">
                <h1><a href="index.html">College Portal</a></h1>
                <p>PHP Cooperation ltd.</p>
            </div>

            <br class="clear" />
        </div>
    </div>

    <!-- ####################################################################################################### -->
    <div id="topbar">
        <div class="wrapper">
            <div id="topnav">
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="college.html">College Info</a></li>
                    <li class="active"><a href="search.html">Search and Compare</a></li>
                    <li><a href="submit.html">Submit College Info</a></li>
                    <li><a href="review.html">Rate/Review Colleges</a></li>
                </ul>
            </div>

            <br class="clear" /><br />
        </div>
    </div>

    <div id="container">
        <div class="wrapper">
            <h1><font size="+3">Search for colleges below: </font></h1>
        </div>
    </div>

    <!-- ####################################################################################################### -->
    <div id="container">
        <div class="wrapper">
        <?php
            $content = $_POST['content'];
            $rating = $_POST['rating'];
            $price =$_POST['price'];
            $place =$_POST['place'];

            if (isset($_POST['submitted'])){
                $conn = mysqli_connect('localhost','root','');
                mysqli_select_db($conn,'college');
                $sql = 'SELECT content, rating, price, place
                        FROM college
                        WHERE content LIKE "%$content%", rating = $rating, price LIKE "%$price%", place LIKE "%$place%"';
                $retval = mysqli_query( $conn, $sql);
                        
                if(!$retval){
                    echo "<p style=\"color:red;\">Unable to retreive data.</p>";
                }
                
                $result = mysqli_query($conn, $sql) or die(mysqli_error($conn));

                if (mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                    echo "
                    <table cellpadding=\"0\" border=\"1\">
                    <tr>
                        <th>College</th>
                        <th>Location</th>
                        <th>Price</th>
                        <th>Ratings</th>
                    </tr>
            
                    <tr>
                        <td>{$row['content']}</td>
                        <td>{$row['place']}</td>
                        <td>{$row['price']}</td>
                        <td>{$row['rating']}</td>
                    </tr>
                    </table>";
                    }
                } 
                else {
                    echo "0 results";
                }

                mysqli_close ($conn);
            }

            else{
                echo "
                <form method=\"post\" action=\"search.php\">
                <p>Please insert criterias: </p>
                <input type=\"text\" name=\"content\" size=\"55\"/>

                <p>Ratings(optional): 
                    <select name=\"rating\">
                        <option value=\" \">-</option>
                        <option value=\"1\">&#9733;1</option>
                        <option value=\"2\">&#9733;2</option>
                        <option value=\"3\">&#9733;3</option>
                        <option value=\"4\">&#9733;4</option>
                        <option value=\"5\">&#9733;5</option>
                    </select>
                </p>

                <p>Price Range(optional): 
                    <select name=\"price\">
                        <option value=\" \">-</option>
                        <option value=\"15000\">Below RM15000</option>
                        <option value=\"17500\">Below RM17500</option>
                        <option value=\"20000\">Below RM20000</option>
                        <option value=\"22500\">Below RM22500</option>
                        <option value=\"25000\">Below RM25000</option>
                    </select>
                </p>

                <p>Location(optional):</p>
                <input type=\"text\" name=\"place\" size=\"55\"/>

                <br /><br />

                <input type=\"submit\" value=\"Search\"/>
                <input type=\"hidden\" name=\"submitted\" value=\"true\" />
                </form>";
            }

        ?>
        </div>
    </div>

    <!-- ####################################################################################################### -->
    <div id="footer">
        <div class="wrapper">
            <div class="footbox">
                <h2>Footer Navigation</h2>
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="college.html">College Info</a></li>
                    <li><a href="search.html">Search and Compare</a></li>
                    <li><a href="submit.html">Submit College Info</a></li>
                    <li><a href="review.html">Rate/Review Colleges</a></li>
                </ul>
            </div>

            <br class="clear" />
        </div>
    </div>

    <!-- ####################################################################################################### -->
    <div id="copyright">
        <div class="wrapper">
            <p class="fl_left">Copyright &copy; 2020 - All Rights Reserved - PHP Assignment</p>
            <p class="fl_right">Template by <a target="_blank" href="http://www.os-templates.com/" title="Free Website Templates">OS Templates</a></p>
            <br class="clear" />
        </div>
    </div>

</body>

</html>