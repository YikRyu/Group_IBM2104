//Admin can submit information of the college to the portal

